package com.tnisf.product;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Product {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer Id;
	private String name;
	private String description;
	private double price;
	private int stockQuantity;
	private String category;
	private int storeId;


public Product() {
	super();
}
	
	@Override
public String toString() {
	return "Product [Id=" + Id + ", name=" + name + ", description=" + description + ", price=" + price
			+ ", stockQuantity=" + stockQuantity + ", category=" + category + ", storeId=" + storeId + ", getId()="
			+ getId() + ", getName()=" + getName() + ", getDescription()=" + getDescription() + ", getPrice()="
			+ getPrice() + ", getStockQuantity()=" + getStockQuantity() + ", getCategory()=" + getCategory()
			+ ", getStoreId()=" + getStoreId() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
			+ ", toString()=" + super.toString() + "]";
}

	public Integer getId() {
	return Id;
}

public void setId(Integer id) {
	this.Id  = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public double getPrice() {
	return price;
}

public void setPrice(double price) {
	this.price = price;
}

public int getStockQuantity() {
	return stockQuantity;
}

public void setStockQuantity(int stockQuantity) {
	this.stockQuantity = stockQuantity;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public int getStoreId() {
	return storeId;
}

public void setStoreId(int storeId) {
	this.storeId = storeId;
}

	

	public Product( String name, String description, double price, int stockQuantity, String category,
			int storeId) {
		super();

		this.name = name;
		this.description = description;
		this.price = price;
		this.stockQuantity = stockQuantity;
		this.category = category;
		this.storeId = storeId;
	}
}	
