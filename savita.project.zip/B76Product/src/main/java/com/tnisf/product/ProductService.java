package com.tnisf.product;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class ProductService {
	@Autowired
	private ProductRepository repositroy;
	public List<Product>listAll(){
	return repositroy.findAll();
	}
	public Product get(Integer id) {
		return repositroy.findById(id).get();
		
	}
	public Product save(Product product) {
		return repositroy.save(product);
		
	}
	
	public void delete(Integer id)
	{
		repositroy.deleteById(id);
	}
}

